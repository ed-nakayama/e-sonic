
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@protocol DIPDelegate <NSObject>
@required
- (void) onRecognizedWithInt:(int) soundId  soundLevel:(int) soundLevel;
@end


@interface DIP : NSObject

- (NSString*)getDIPVersion;
- (NSString*)getSPLVersion;

- (id)init;
- (void)finalize;

- (void)open;
- (void)close;
- (BOOL)isOpen;

- (void)setDIPDelegate:(id<DIPDelegate>)delegate;

@end

